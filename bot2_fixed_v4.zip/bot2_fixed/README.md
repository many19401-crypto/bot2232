# 🎵 Discord Music Bot v2

## 📁 Структура проекта

```
discord_music_bot_v2/
│
├── bot.py                  # Точка входа, загрузка cog-ов
│
├── cogs/                   # Каждая команда — отдельный файл
│   ├── play.py             # !play
│   ├── controls.py         # !pause !resume !skip !stop !nowplaying !panel
│   ├── queue.py            # !queue !clear
│   ├── volume.py           # !volume
│   ├── voice.py            # !join !leave
│   └── help.py             # !help
│
├── utils/                  # Переиспользуемая логика
│   ├── state.py            # Хранилище состояния серверов
│   ├── track.py            # Датакласс трека + yt-dlp поиск
│   ├── player.py           # Ядро воспроизведения + переход треков
│   ├── embeds.py           # Все Discord embed-шаблоны
│   └── panel_view.py       # Кнопки управления (discord.ui.View)
│
├── requirements.txt
├── .env.example
└── README.md
```

---

## ⚙️ Установка

```bash
# 1. Зависимости Python
pip install -r requirements.txt

# 2. FFmpeg
# Linux:   sudo apt install ffmpeg
# macOS:   brew install ffmpeg
# Windows: https://ffmpeg.org/download.html → добавить bin/ в PATH

# 3. Токен бота
cp .env.example .env
# Открой .env и вставь токен

# 4. Запуск
python bot.py
```

---

## 🎮 Команды

| Команда | Файл | Описание |
|---|---|---|
| `!play <запрос>` | `cogs/play.py` | Включить музыку / добавить в очередь |
| `!pause` | `cogs/controls.py` | Пауза |
| `!resume` | `cogs/controls.py` | Продолжить |
| `!skip` | `cogs/controls.py` | Пропустить |
| `!stop` | `cogs/controls.py` | Стоп + выход из канала |
| `!nowplaying` | `cogs/controls.py` | Текущий трек |
| `!panel` | `cogs/controls.py` | Панель управления кнопками |
| `!queue` | `cogs/queue.py` | Показать очередь |
| `!clear` | `cogs/queue.py` | Очистить очередь |
| `!volume <0-100>` | `cogs/volume.py` | Громкость |
| `!join` | `cogs/voice.py` | Зайти в канал |
| `!leave` | `cogs/voice.py` | Выйти из канала |
| `!help` | `cogs/help.py` | Список команд |
