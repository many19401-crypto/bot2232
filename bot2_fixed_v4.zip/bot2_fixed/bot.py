import os
import discord
import importlib.util
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()

COGS = (
    "cogs.play",
    "cogs.controls",
    "cogs.queue",
    "cogs.volume",
    "cogs.voice",
    "cogs.help",
    "cogs.autorole",
)


class MusicBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.voice_states = True
        intents.members = True
        super().__init__(command_prefix="!", intents=intents, help_command=None)

    async def setup_hook(self):
        for cog in COGS:
            try:
                await self.load_extension(cog)
                print(f"[OK] Загружен: {cog}")
            except Exception as exc:
                print(f"[ERROR] Не удалось загрузить {cog}: {exc}")


    async def on_ready(self):
        if not getattr(self, "_views_registered", False):
            from utils.panel_view import MusicControlView
            for guild in self.guilds:
                self.add_view(MusicControlView(guild.id))
            self._views_registered = True

        print(f"\n[OK] Бот запущен как {self.user}")
        print(f"[INFO] Серверов: {len(self.guilds)}")
        print(f"[INFO] discord.py: {discord.__version__}")
        print(f"[INFO] davey: {'установлен' if importlib.util.find_spec('davey') else 'НЕ НАЙДЕН'}\n")
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.listening,
                name="музыку | !help",
            )
        )


TOKEN = os.getenv("DISCORD_TOKEN")
if not TOKEN:
    raise RuntimeError("DISCORD_TOKEN не найден в .env")

bot = MusicBot()
bot.run(TOKEN)
