"""
utils/panel_view.py
discord.ui.View с кнопками управления музыкой.
Отдельный файл, чтобы избежать циклических импортов.
"""
import discord
import utils.state as state
import utils.embeds as embeds
from utils.track import Track


class MusicControlView(discord.ui.View):
    def __init__(self, guild_id: int):
        super().__init__(timeout=None)
        self.guild_id = guild_id

    # ── Пауза / Продолжить ───────────────────────────────────────────────────
    @discord.ui.button(emoji="⏸️", label="Пауза", style=discord.ButtonStyle.secondary, custom_id="mc_pause")
    async def pause_resume(self, interaction: discord.Interaction, button: discord.ui.Button):
        vc = interaction.guild.voice_client
        if not vc:
            return await interaction.response.send_message("❌ Бот не в голосовом канале", ephemeral=True)

        if vc.is_paused():
            vc.resume()
            button.emoji = "⏸️"
            button.label = "Пауза"
            await interaction.response.edit_message(view=self)
        elif vc.is_playing():
            vc.pause()
            button.emoji = "▶️"
            button.label = "Продолжить"
            await interaction.response.edit_message(view=self)
        else:
            await interaction.response.send_message("❌ Ничего не играет", ephemeral=True)

    # ── Пропустить ───────────────────────────────────────────────────────────
    @discord.ui.button(emoji="⏭️", label="Пропустить", style=discord.ButtonStyle.primary, custom_id="mc_skip")
    async def skip(self, interaction: discord.Interaction, button: discord.ui.Button):
        vc = interaction.guild.voice_client
        if not vc or not (vc.is_playing() or vc.is_paused()):
            return await interaction.response.send_message("❌ Ничего не играет", ephemeral=True)
        vc.stop()
        await interaction.response.send_message("⏭️ Трек пропущен", ephemeral=True)

    # ── Стоп ─────────────────────────────────────────────────────────────────
    @discord.ui.button(emoji="⏹️", label="Стоп", style=discord.ButtonStyle.danger, custom_id="mc_stop")
    async def stop(self, interaction: discord.Interaction, button: discord.ui.Button):
        s = state.get(self.guild_id)
        s["queue"].clear()
        vc = interaction.guild.voice_client
        if vc:
            vc.stop()
            await vc.disconnect()
        await interaction.response.send_message("⏹️ Остановлено", ephemeral=True)

    # ── Очередь ──────────────────────────────────────────────────────────────
    @discord.ui.button(emoji="📋", label="Очередь", style=discord.ButtonStyle.secondary, custom_id="mc_queue")
    async def queue_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        s = state.get(self.guild_id)
        if not s["queue"]:
            return await interaction.response.send_message("📭 Очередь пуста", ephemeral=True)
        embed = embeds.queue_embed(s["current"], list(s["queue"]))
        await interaction.response.send_message(embed=embed, ephemeral=True)

    # ── Текущий трек ─────────────────────────────────────────────────────────
    @discord.ui.button(emoji="🎵", label="Сейчас играет", style=discord.ButtonStyle.secondary, custom_id="mc_np", row=1)
    async def now_playing(self, interaction: discord.Interaction, button: discord.ui.Button):
        s = state.get(self.guild_id)
        if not s["current"]:
            return await interaction.response.send_message("❌ Ничего не играет", ephemeral=True)
        embed = embeds.now_playing(s["current"])
        await interaction.response.send_message(embed=embed, ephemeral=True)

    # ── Громкость ────────────────────────────────────────────────────────────
    @discord.ui.button(emoji="🔊", label="Громкость", style=discord.ButtonStyle.secondary, custom_id="mc_vol", row=1)
    async def volume_info(self, interaction: discord.Interaction, button: discord.ui.Button):
        s = state.get(self.guild_id)
        vol = int(s.get("volume", 0.5) * 100)
        await interaction.response.send_message(
            f"🔊 Текущая громкость: **{vol}%**\nИспользуй `!volume <0-100>` для изменения",
            ephemeral=True,
        )
