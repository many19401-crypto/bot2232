import asyncio
import re
import yt_dlp

YTDL_OPTIONS = {
    "format": "bestaudio/best",
    "noplaylist": False,
    "nocheckcertificate": True,
    "ignoreerrors": False,
    "quiet": True,
    "no_warnings": True,
    "default_search": "ytsearch5",      # Увеличил количество результатов
    "source_address": "0.0.0.0",
    "extract_flat": False,
}

_ytdl = yt_dlp.YoutubeDL(YTDL_OPTIONS)


class Track:
    def __init__(self, url: str, title: str, duration: int, thumbnail: str, webpage_url: str, requester):
        self.url = url
        self.title = title
        self.duration = duration
        self.thumbnail = thumbnail
        self.webpage_url = webpage_url
        self.requester = requester

    @classmethod
    async def from_query(cls, query: str, requester, loop=None) -> list["Track"]:
        loop = loop or asyncio.get_event_loop()

        # Очистка запроса
        clean_query = re.sub(r'\(.*?\)', '', query).strip()
        
        is_url = bool(re.match(r'https?://', query))
        search_query = query if is_url else f"ytsearch5:{clean_query}"

        try:
            data = await loop.run_in_executor(
                None, lambda: _ytdl.extract_info(search_query, download=False)
            )
        except Exception as e:
            # Fallback без префикса
            data = await loop.run_in_executor(
                None, lambda: _ytdl.extract_info(f"ytsearch5:{clean_query}", download=False)
            )

        entries = data.get("entries") if data and "entries" in data else [data]
        entries = [e for e in entries if e]

        if not entries:
            raise ValueError("Ничего не найдено")

        return [
            cls(
                url=e.get("url") or (e.get("formats") or [{}])[0].get("url", ""),
                title=e.get("title", "Неизвестно"),
                duration=e.get("duration", 0),
                thumbnail=e.get("thumbnail", ""),
                webpage_url=e.get("webpage_url", e.get("url", "")),
                requester=requester,
            )
            for e in entries[:10]  # Ограничиваем 10 результатами
        ]

    @staticmethod
    def fmt_duration(seconds: int) -> str:
        if not seconds:
            return "∞"
        m, s = divmod(int(seconds), 60)
        h, m = divmod(m, 60)
        return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"

    def __repr__(self):
        return f"<Track title={self.title!r}>" 