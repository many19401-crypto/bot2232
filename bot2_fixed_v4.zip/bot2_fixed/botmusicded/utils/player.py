"""
utils/player.py
Ядро воспроизведения: FFmpeg-источник, переход к следующему треку,
обновление панели управления.
"""
import asyncio
import random
import discord

from utils.track import Track
import utils.state as state
import utils.embeds as embeds
from utils.panel_view import MusicControlView

FFMPEG_BEFORE_OPTS = "-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5"

MUSIC_GIFS = [
    "https://media4.giphy.com/media/v1.Y2lkPTc5MGI3NjExcm03c3lxczcyaGZjNnp2N29jMjZmdmZpamNjYnY1MTk1dzFkb2NocCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/IKFVtPf8jP6KJH16dB/giphy.gif",
    "https://media2.giphy.com/media/v1.Y2lkPTc5MGI3NjExYTdkYWQ2ZW9wdGFpOWMyZ2tudzBkZWNxZWZ5aXZreDl6dndma3VwYSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/tBDLxi8N6VO9aoEzgi/giphy.gif",
    "https://media3.giphy.com/media/v1.Y2lkPTc5MGI3NjExcjI3bnBxNnc4djU2ejVnc24zajNyc3oyNjB2dmwyb2t2cGQ0dDdhNCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/3NP6Lye3xcFxYkbibz/giphy.gif",
    "https://media.giphy.com/media/sC1j6UV8P0Jo3He2LP/giphy-downsized-large.gif",
    "https://media0.giphy.com/media/v1.Y2lkPTc5MGI3NjExcG04YmNtbWZ6OWt5Ym16ZzN2azQ3c3ZoMGs5aWkwZWxxbXVkaHl5bCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/k1U23cZsNOTrn0rnPv/giphy.gif",
]


def _make_source(url: str, volume: float) -> discord.FFmpegPCMAudio:
    return discord.FFmpegPCMAudio(
        url,
        before_options=FFMPEG_BEFORE_OPTS,
        options=f"-vn -filter:a 'volume={volume}'",
    )


async def play_next(guild: discord.Guild, text_channel: discord.TextChannel, bot) -> None:
    """
    Взять следующий трек из очереди и начать воспроизведение.
    При смене трека обновляет или создаёт панель управления.
    """
    s = state.get(guild.id)
    vc: discord.VoiceClient | None = guild.voice_client

    if not vc or not s["queue"]:
        s["current"] = None
        # Очередь закончилась — обновляем панель
        if s["panel_message"]:
            try:
                await s["panel_message"].edit(embed=embeds.stopped(), view=None)
            except Exception:
                pass
            s["panel_message"] = None
        return

    track: Track = s["queue"].popleft()
    s["current"] = track

    source = _make_source(track.url, s["volume"])

    def after(error):
        if error:
            print(f"[player] Ошибка: {error}")
        asyncio.run_coroutine_threadsafe(
            play_next(guild, text_channel, bot), bot.loop
        )

    vc.play(source, after=after)

    panel_embed = embeds.panel(track, len(s["queue"]))
    view = MusicControlView(guild.id)

    # Попытка обновить существующую панель
    if s["panel_message"]:
        try:
            await s["panel_message"].edit(embed=panel_embed, view=view)
            return
        except Exception:
            s["panel_message"] = None

    # Нет панели — отправляем GIF + новую панель
    await text_channel.send(embed=embeds.gif(random.choice(MUSIC_GIFS)))
    s["panel_message"] = await text_channel.send(embed=panel_embed, view=view)
