"""
utils/state.py
Глобальное хранилище состояния для каждого сервера (guild).
Все cog-и обращаются сюда — никакого дублирования данных.
"""
from collections import deque

# { guild_id: { queue, current, volume, panel_message } }
_states: dict[int, dict] = {}


def get(guild_id: int) -> dict:
    """Вернуть состояние сервера, создав его при необходимости."""
    if guild_id not in _states:
        _states[guild_id] = {
            "queue": deque(),
            "current": None,       # Track | None
            "volume": 0.5,         # 0.0 – 1.0
            "panel_message": None, # discord.Message | None
        }
    return _states[guild_id]


def clear(guild_id: int) -> None:
    """Сбросить состояние сервера."""
    if guild_id in _states:
        _states[guild_id]["queue"].clear()
        _states[guild_id]["current"] = None
        _states[guild_id]["panel_message"] = None
