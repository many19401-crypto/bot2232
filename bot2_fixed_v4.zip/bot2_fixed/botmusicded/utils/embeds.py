"""
utils/embeds.py
Все embed-шаблоны в одном месте.
"""
import discord
from utils.track import Track


def now_playing(track: Track) -> discord.Embed:
    """Embed текущего трека."""
    embed = discord.Embed(
        title="🎵 Сейчас играет",
        description=f"**[{track.title}]({track.webpage_url})**",
        color=discord.Color.purple(),
    )
    embed.add_field(name="⏱ Длительность", value=Track.fmt_duration(track.duration), inline=True)
    embed.add_field(name="👤 Запросил", value=track.requester.mention, inline=True)
    if track.thumbnail:
        embed.set_thumbnail(url=track.thumbnail)
    return embed


def panel(track: Track, queue_size: int) -> discord.Embed:
    """Embed панели управления."""
    embed = discord.Embed(title="🎛️ Панель управления", color=discord.Color.purple())
    embed.add_field(
        name="🎵 Сейчас играет",
        value=f"**[{track.title}]({track.webpage_url})**",
        inline=False,
    )
    embed.add_field(name="⏱ Длительность", value=Track.fmt_duration(track.duration), inline=True)
    embed.add_field(name="📋 В очереди", value=str(queue_size), inline=True)
    embed.add_field(name="👤 Запросил", value=track.requester.mention, inline=True)
    if track.thumbnail:
        embed.set_image(url=track.thumbnail)
    embed.set_footer(text="Используй кнопки ниже для управления")
    return embed


def added_to_queue(track: Track, position: int) -> discord.Embed:
    """Embed подтверждения добавления в очередь."""
    embed = discord.Embed(
        title="📋 Добавлено в очередь",
        description=f"**[{track.title}]({track.webpage_url})**",
        color=discord.Color.green(),
    )
    embed.add_field(name="⏱ Длительность", value=Track.fmt_duration(track.duration), inline=True)
    embed.add_field(name="📍 Позиция", value=str(position), inline=True)
    if track.thumbnail:
        embed.set_thumbnail(url=track.thumbnail)
    return embed


def playlist_added(count: int) -> discord.Embed:
    """Embed для добавленного плейлиста."""
    return discord.Embed(
        title="📋 Плейлист добавлен",
        description=f"**{count} треков** добавлено в очередь",
        color=discord.Color.green(),
    )


def queue_embed(current: Track | None, queue: list[Track]) -> discord.Embed:
    """Embed полной очереди."""
    embed = discord.Embed(title="📋 Очередь воспроизведения", color=discord.Color.blurple())
    if current:
        embed.add_field(
            name="🎵 Сейчас играет",
            value=f"[{current.title}]({current.webpage_url}) — {Track.fmt_duration(current.duration)}",
            inline=False,
        )
    if queue:
        visible = queue[:15]
        lines = [
            f"`{i+1}.` [{t.title}]({t.webpage_url}) — {Track.fmt_duration(t.duration)}"
            for i, t in enumerate(visible)
        ]
        embed.add_field(name=f"📋 Далее ({len(queue)})", value="\n".join(lines), inline=False)
        if len(queue) > 15:
            embed.set_footer(text=f"...и ещё {len(queue) - 15} треков")
    return embed


def stopped() -> discord.Embed:
    """Embed когда очередь закончилась."""
    return discord.Embed(
        title="⏹️ Воспроизведение завершено",
        description="Очередь пуста. Используй `!play` чтобы добавить музыку.",
        color=discord.Color.greyple(),
    )


def gif(url: str) -> discord.Embed:
    """Embed с GIF-анимацией."""
    embed = discord.Embed(color=discord.Color.purple())
    embed.set_image(url=url)
    return embed
