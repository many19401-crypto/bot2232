import discord
from discord.ext import commands
import random
import asyncio
import aiohttp

class Fun(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # ===================== РАЗВЛЕЧЕНИЯ =====================

    @commands.command()
    async def meme(self, ctx):
        """Случайный мем"""
        async with aiohttp.ClientSession() as session:
            async with session.get("https://meme-api.com/gimme") as resp:
                data = await resp.json()
                embed = discord.Embed(color=discord.Color.random())
                embed.set_image(url=data['url'])
                embed.set_footer(text=f"👍 {data['ups']} | r/{data['subreddit']}")
                await ctx.send(embed=embed)

    @commands.command()
    async def pp(self, ctx, member: discord.Member = None):
        """Измеритель достоинства"""
        member = member or ctx.author
        size = random.randint(1, 30)
        pp = "═" * size
        embed = discord.Embed(
            title="PP Machine 3000",
            description=f"{member.mention}\n8{pp}D\n**Размер:** {size} см",
            color=0xFF69B4
        )
        await ctx.send(embed=embed)

    @commands.command()
    async def roast(self, ctx, member: discord.Member = None):
        """Троллинг участника"""
        if not member:
            member = ctx.author
        roasts = [
            "Ты настолько тупой, что даже Google не знает, как тебе помочь.",
            "Твой мозг — это как интернет в 1995 году: медленно и почти ничего не работает.",
            "Если бы мозг был динамитом, у тебя бы даже на нос не хватило.",
            "Ты как Wi-Fi в подвале — иногда ловишь, но в основном бесполезен.",
            "Я бы сказал, что ты красивый, но у меня совесть есть."
        ]
        await ctx.send(f"{member.mention}, {random.choice(roasts)}")

    @commands.command(name="8ball")
    async def eight_ball(self, ctx, *, question: str = None):
        """Магический шар 8ball"""
        if not question:
            return await ctx.send("❌ Задай вопрос!")
        answers = ["Да.", "Нет.", "Возможно.", "Скорее всего.", "Не думаю.", "Точно да!", "Спроси позже.", "Мой ответ — нет."]
        embed = discord.Embed(title="🎱 Магический шар", description=f"**Вопрос:** {question}\n**Ответ:** {random.choice(answers)}", color=discord.Color.purple())
        await ctx.send(embed=embed)

    @commands.command()
    async def ship(self, ctx, user1: discord.Member, user2: discord.Member = None):
        """Шиппинг двух участников"""
        if not user2:
            user2 = ctx.author
        percent = random.randint(0, 100)
        if percent > 80:
            heart = "❤️"
        elif percent > 50:
            heart = "💖"
        else:
            heart = "💔"
        
        embed = discord.Embed(
            title="💘 Ship Machine",
            description=f"{user1.mention} × {user2.mention}\n**Совместимость:** {percent}% {heart}",
            color=discord.Color.from_rgb(255, 105, 180)
        )
        await ctx.send(embed=embed)

    @commands.command()
    async def howgay(self, ctx, member: discord.Member = None):
        """Насколько гей?"""
        member = member or ctx.author
        percent = random.randint(0, 100)
        embed = discord.Embed(
            title="🏳️‍🌈 Gay-O-Meter",
            description=f"{member.mention} — **{percent}%** гей",
            color=0xFF69B4
        )
        await ctx.send(embed=embed)

    @commands.command()
    async def howcute(self, ctx, member: discord.Member = None):
        """Насколько милый?"""
        member = member or ctx.author
        percent = random.randint(30, 100)
        embed = discord.Embed(
            title="🥰 Cute-O-Meter",
            description=f"{member.mention} — **{percent}%** милоты",
            color=discord.Color.pink()
        )
        await ctx.send(embed=embed)

    # ===================== ИНФОРМАЦИЯ =====================

    @commands.command()
    async def avatar(self, ctx, member: discord.Member = None):
        """Большая аватарка"""
        member = member or ctx.author
        embed = discord.Embed(title=f"Аватарка {member}", color=discord.Color.blue())
        embed.set_image(url=member.display_avatar.url)
        await ctx.send(embed=embed)

    @commands.command()
    async def userinfo(self, ctx, member: discord.Member = None):
        """Информация об участнике"""
        member = member or ctx.author
        embed = discord.Embed(title=f"Информация о {member}", color=discord.Color.blue())
        embed.add_field(name="ID", value=member.id, inline=True)
        embed.add_field(name="Статус", value=member.status, inline=True)
        embed.add_field(name="Присоединился", value=member.joined_at.strftime("%d.%m.%Y"), inline=True)
        embed.add_field(name="Аккаунт создан", value=member.created_at.strftime("%d.%m.%Y"), inline=True)
        embed.set_thumbnail(url=member.display_avatar.url)
        await ctx.send(embed=embed)

    # ===================== МУЗЫКА =====================

    @commands.command()
    async def lyrics(self, ctx):
        """Текст текущей песни (заглушка)"""
        await ctx.send("🔍 **Текст песни**\n\n(Пока что заглушка. Можно подключить API Genius позже)")

    # ===================== АВТО-РЕАКЦИИ =====================

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return

        content = message.content.lower()

        if "кринж" in content:
            await message.add_reaction("🤮")
        elif "лол" in content or "лмао" in content:
            await message.add_reaction("😂")
        elif "соси" in content:
            await message.add_reaction("🍆")
        elif "пиздец" in content:
            await message.add_reaction("💀")


async def setup(bot):
    await bot.add_cog(Fun(bot))