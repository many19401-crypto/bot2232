"""
cogs/queue.py
Управление очередью: просмотр и очистка.
"""
from discord.ext import commands

import utils.state as state
import utils.embeds as embeds


class Queue(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # ── Показать очередь ─────────────────────────────────────────────────────
    @commands.command(name="queue", aliases=["q"])
    async def queue_cmd(self, ctx: commands.Context):
        """Показать список треков в очереди"""
        s = state.get(ctx.guild.id)
        if not s["queue"] and not s["current"]:
            return await ctx.send("📭 Очередь пуста")
        embed = embeds.queue_embed(s["current"], list(s["queue"]))
        await ctx.send(embed=embed)

    # ── Очистить очередь ─────────────────────────────────────────────────────
    @commands.command(name="clear")
    async def clear(self, ctx: commands.Context):
        """Очистить очередь (текущий трек продолжает играть)"""
        s = state.get(ctx.guild.id)
        count = len(s["queue"])
        s["queue"].clear()
        await ctx.send(f"🗑️ Очередь очищена ({count} треков удалено)")


async def setup(bot):
    await bot.add_cog(Queue(bot))
