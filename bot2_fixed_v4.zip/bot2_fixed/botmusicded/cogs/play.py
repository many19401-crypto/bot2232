import discord
from discord.ext import commands
from discord.ui import View, Button

import utils.state as state
import utils.embeds as embeds
from utils.track import Track
from utils.player import play_next


async def _ensure_voice(ctx: commands.Context):
    if not ctx.author.voice:
        await ctx.send("❌ Сначала зайди в голосовой канал!")
        return None
    channel = ctx.author.voice.channel
    if ctx.voice_client:
        if ctx.voice_client.channel != channel:
            await ctx.voice_client.move_to(channel)
        return ctx.voice_client
    return await channel.connect()


class TrackSelectView(View):
    def __init__(self, tracks, ctx, bot):
        super().__init__(timeout=60)
        self.tracks = tracks
        self.ctx = ctx
        self.bot = bot

    async def play(self, interaction: discord.Interaction, index: int):
        track = self.tracks[index]
        s = state.get(self.ctx.guild.id)
        vc = self.ctx.voice_client

        s["queue"].append(track)

        if vc.is_playing() or vc.is_paused():
            await interaction.response.send_message(embed=embeds.added_to_queue(track, len(s["queue"])))
        else:
            await play_next(self.ctx.guild, self.ctx.channel, self.bot)
            await interaction.response.send_message(f"▶️ **Сейчас играет:** {track.title}")

        self.stop()

    @discord.ui.button(label="1", style=discord.ButtonStyle.primary)
    async def one(self, interaction: discord.Interaction, button: Button):
        await self.play(interaction, 0)

    @discord.ui.button(label="2", style=discord.ButtonStyle.primary)
    async def two(self, interaction: discord.Interaction, button: Button):
        await self.play(interaction, 1)

    @discord.ui.button(label="3", style=discord.ButtonStyle.primary)
    async def three(self, interaction: discord.Interaction, button: Button):
        await self.play(interaction, 2)

    @discord.ui.button(label="4", style=discord.ButtonStyle.primary)
    async def four(self, interaction: discord.Interaction, button: Button):
        await self.play(interaction, 3)

    @discord.ui.button(label="5", style=discord.ButtonStyle.primary)
    async def five(self, interaction: discord.Interaction, button: Button):
        await self.play(interaction, 4)

    @discord.ui.button(label="Отмена", style=discord.ButtonStyle.gray, row=1)
    async def cancel(self, interaction: discord.Interaction, button: Button):
        await interaction.response.send_message("Поиск отменён.", ephemeral=True)
        self.stop()


class Play(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="play", aliases=["p"])
    async def play(self, ctx: commands.Context, *, query: str = None):
        if not query:
            return await ctx.send("❌ Укажи название или ссылку: `!play <запрос>`")

        vc = await _ensure_voice(ctx)
        if not vc:
            return

        s = state.get(ctx.guild.id)
        is_url = query.startswith(("http://", "https://", "www."))

        async with ctx.typing():
            try:
                tracks = await Track.from_query(query, ctx.author, self.bot.loop)
            except Exception as e:
                return await ctx.send(f"❌ Ошибка поиска: `{e}`")

        if not tracks:
            return await ctx.send("❌ Ничего не найдено.")

        # Если это прямая ссылка или плейлист — добавляем всё
        if is_url or len(tracks) > 5:
            for t in tracks:
                s["queue"].append(t)
            if len(tracks) > 1:
                await ctx.send(embed=embeds.playlist_added(len(tracks)))
            else:
                if not (vc.is_playing() or vc.is_paused()):
                    await play_next(ctx.guild, ctx.channel, self.bot)
            return

        # Если это обычный поиск — показываем выбор
        embed = discord.Embed(
            title="Результаты поиска",
            description="Выберите трек:",
            color=discord.Color.blue()
        )
        for i, track in enumerate(tracks[:5], 1):
            embed.add_field(
                name=f"{i}. {track.title}",
                value=f"Длительность: `{Track.fmt_duration(track.duration)}`",
                inline=False
            )

        view = TrackSelectView(tracks[:5], ctx, self.bot)
        await ctx.send(embed=embed, view=view)


    @play.error
    async def play_error(self, ctx, error):
        if isinstance(error, commands.MissingRequiredArgument):
            await ctx.send("❌ Укажи название или ссылку: `!play <запрос>`")
        else:
            await ctx.send(f"❌ Ошибка: `{error}`")


async def setup(bot):
    await bot.add_cog(Play(bot))