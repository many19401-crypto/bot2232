"""
cogs/voice.py
Подключение и отключение от голосового канала.
"""
from discord.ext import commands


class Voice(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="join", aliases=["j"])
    async def join(self, ctx: commands.Context):
        """Зайти в твой голосовой канал"""
        if not ctx.author.voice:
            return await ctx.send("❌ Сначала зайди в голосовой канал!")
        channel = ctx.author.voice.channel
        if ctx.voice_client:
            await ctx.voice_client.move_to(channel)
            await ctx.send(f"➡️ Перешёл в **{channel.name}**")
        else:
            await channel.connect()
            await ctx.send(f"✅ Зашёл в **{channel.name}**")

    @commands.command(name="leave", aliases=["dc", "disconnect"])
    async def leave(self, ctx: commands.Context):
        """Выйти из голосового канала"""
        if ctx.voice_client:
            await ctx.voice_client.disconnect()
            await ctx.send("👋 Вышел из канала")
        else:
            await ctx.send("❌ Я не в голосовом канале")


async def setup(bot):
    await bot.add_cog(Voice(bot))
