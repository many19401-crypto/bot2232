"""
cogs/volume.py
Регулировка громкости воспроизведения.
"""
from discord.ext import commands

import utils.state as state


class Volume(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="volume", aliases=["vol", "v"])
    async def volume(self, ctx: commands.Context, vol: int):
        """Установить громкость от 0 до 100"""
        if not 0 <= vol <= 100:
            return await ctx.send("❌ Громкость должна быть от **0** до **100**")

        s = state.get(ctx.guild.id)
        s["volume"] = vol / 100

        # Применить к текущему источнику, если есть
        vc = ctx.voice_client
        if vc and vc.source:
            vc.source.volume = vol / 100

        bar_filled = round(vol / 10)
        bar = "█" * bar_filled + "░" * (10 - bar_filled)
        await ctx.send(f"🔊 `{bar}` **{vol}%**")

    @volume.error
    async def volume_error(self, ctx, error):
        if isinstance(error, commands.BadArgument):
            await ctx.send("❌ Укажи число: `!volume 75`")
        elif isinstance(error, commands.MissingRequiredArgument):
            s = state.get(ctx.guild.id)
            vol = int(s.get("volume", 0.5) * 100)
            await ctx.send(f"🔊 Текущая громкость: **{vol}%**\nИспользуй `!volume <0-100>` для изменения")


async def setup(bot):
    await bot.add_cog(Volume(bot))
