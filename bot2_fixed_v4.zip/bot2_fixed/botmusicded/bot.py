import discord
from discord.ext import commands
import os
from dotenv import load_dotenv

load_dotenv()

intents = discord.Intents.default()
intents.message_content = True
intents.voice_states = True
intents.members = True        # Нужно для autorole (on_member_join)

bot = commands.Bot(command_prefix="!", intents=intents, help_command=None)

COGS = [
    "cogs.play",
    "cogs.controls",
    "cogs.queue",
    "cogs.volume",
    "cogs.voice",
    "cogs.help",
    "cogs.autorole",
    "cogs.fun",
]

@bot.event
async def on_ready():
    print(f"\n✅ Бот запущен как {bot.user}")
    print(f"📡 На {len(bot.guilds)} серверах\n")
    
    await bot.change_presence(
        activity=discord.Activity(
            type=discord.ActivityType.listening,
            name="музыку | !help"
        )
    )
    
    for cog in COGS:
        try:
            await bot.load_extension(cog)
            print(f"✅ Загружен: {cog}")
        except Exception as e:
            print(f"❌ Ошибка загрузки {cog}: {e}")

bot.run(os.getenv("DISCORD_TOKEN"))