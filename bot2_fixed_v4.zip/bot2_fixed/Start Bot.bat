@echo off
chcp 65001 >nul
title 🎵 Музыкальный Бот - Запуск

cd /d "%~dp0"

echo.
echo ================================================
echo        Запуск музыкального бота...
echo ================================================
echo.

if exist venv\Scripts\python.exe (
    echo [OK] Виртуальное окружение найдено.
    set "PYTHON=venv\Scripts\python.exe"
) else (
    echo [WARN] Виртуальное окружение не найдено. Используем глобальный Python.
    set "PYTHON=python"
)

echo.
echo [INFO] Проверяем зависимости Discord Voice/DAVE...
"%PYTHON%" -m pip install -U -r requirements.txt
if errorlevel 1 (
    echo.
    echo [ERROR] Не удалось установить зависимости.
    pause
    exit /b 1
)

echo.
echo [INFO] Версия Discord.py:
"%PYTHON%" -c "import discord; print(discord.__version__)"
echo.
echo [INFO] Проверка DAVE:
"%PYTHON%" -c "import davey; print('davey OK')"
if errorlevel 1 (
    echo [ERROR] davey не установлен. Голос Discord работать не будет.
    pause
    exit /b 1
)

echo.
echo [LAUNCH] Запуск бота...
echo.
"%PYTHON%" bot.py

echo.
echo ================================================
echo                    Бот остановлен.
echo ================================================
pause
