import asyncio
import os
import random
import shutil
import discord

from utils.track import Track
import utils.state as state
import utils.embeds as embeds
from utils.panel_view import MusicControlView

MUSIC_GIFS = [
    "https://media4.giphy.com/media/v1.Y2lkPTc5MGI3NjExcm03c3lxczcyaGZjNnp2N29jMjZmdmZpamNjYnY1MTk1dzFkb2NocCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/IKFVtPf8jP6KJH16dB/giphy.gif",
    "https://media2.giphy.com/media/v1.Y2lkPTc5MGI3NjExYTdkYWQ2ZW9wdGFpOWMyZ2tudzBkZWNxZWZ5aXZreDl6dndma3VwYSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/tBDLxi8N6VO9aoEzgi/giphy.gif",
    "https://media3.giphy.com/media/v1.Y2lkPTc5MGI3NjExcjI3bnBxNnc4djU2ejVnc24zajNyc3oyNjB2dmwyb2t2cGQ0dDdhNCZlcD12MV9pbnRlbnRhbF9naWZfYnlfaWQmY3Q9Zw/3NP6Lye3xcFxYkbibz/giphy.gif",
    "https://media.giphy.com/media/sC1j6UV8P0Jo3He2LP/giphy-downsized-large.gif",
    "https://media0.giphy.com/media/v1.Y2lkPTc5MGI3NjExcG04YmNtbWZ6OWt5Ym16ZzN2azQ3c3ZoMGs5aWkwZWxxbXVkaHl5bCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/k1U23cZsNOTrn0rnPv/giphy.gif",
]


def _make_source(path: str, volume: float) -> discord.PCMVolumeTransformer:
    # Играем локальный файл, а не временный googlevideo CDN URL.
    audio = discord.FFmpegPCMAudio(
        path,
        before_options="-nostdin",
        options="-vn -loglevel warning",
    )
    return discord.PCMVolumeTransformer(audio, volume=volume)


def _cleanup_track(track: Track) -> None:
    path = track.local_path
    track.local_path = None
    if not path:
        return
    try:
        parent = os.path.dirname(path)
        if os.path.isfile(path):
            os.remove(path)
        if parent and os.path.basename(parent).startswith("kavodedafm_") and os.path.isdir(parent):
            shutil.rmtree(parent, ignore_errors=True)
    except OSError as exc:
        print(f"[player] Не удалось удалить временный файл: {exc}")


async def play_next(guild: discord.Guild, text_channel: discord.TextChannel, bot) -> None:
    s = state.get(guild.id)
    vc = guild.voice_client

    if not vc or not s["queue"]:
        if s["current"]:
            _cleanup_track(s["current"])
        s["current"] = None
        if s["panel_message"]:
            try:
                await s["panel_message"].edit(embed=embeds.stopped(), view=None)
            except (discord.HTTPException, discord.NotFound, discord.Forbidden):
                pass
            s["panel_message"] = None
        return

    track: Track = s["queue"].popleft()
    s["current"] = track

    try:
        # Надёжный путь: скачать файл через yt-dlp, затем отдать FFmpeg локальный файл.
        local_path = await track.download_audio(bot.loop)
        source = _make_source(local_path, s["volume"])
    except Exception as exc:
        print(f"[player] Не удалось скачать/подготовить '{track.title}': {exc}")
        _cleanup_track(track)
        s["current"] = None
        await text_channel.send(f"❌ Не удалось воспроизвести **{track.title}**: `{exc}`")
        return await play_next(guild, text_channel, bot)

    def after(error):
        if error:
            print(f"[player] Ошибка воспроизведения '{track.title}': {error}")
        _cleanup_track(track)
        future = asyncio.run_coroutine_threadsafe(
            play_next(guild, text_channel, bot), bot.loop
        )
        try:
            future.result(timeout=0)
        except Exception:
            pass

    try:
        vc.play(source, after=after)
    except Exception as exc:
        print(f"[player] vc.play() failed: {exc}")
        _cleanup_track(track)
        s["current"] = None
        return await play_next(guild, text_channel, bot)

    panel_embed = embeds.panel(track, len(s["queue"]))
    view = MusicControlView(guild.id)

    if s["panel_message"]:
        try:
            await s["panel_message"].edit(embed=panel_embed, view=view)
            return
        except (discord.HTTPException, discord.NotFound, discord.Forbidden):
            s["panel_message"] = None

    await text_channel.send(embed=embeds.gif(random.choice(MUSIC_GIFS)))
    s["panel_message"] = await text_channel.send(embed=panel_embed, view=view)
