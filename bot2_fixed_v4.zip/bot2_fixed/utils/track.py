import asyncio
import re
import os
import tempfile
from dataclasses import dataclass
from typing import Any

import yt_dlp

YTDL_OPTIONS = {
    "format": "bestaudio/best",
    "noplaylist": False,
    "nocheckcertificate": True,
    "ignoreerrors": False,
    "quiet": True,
    "no_warnings": True,
    "default_search": "ytsearch5",
    "source_address": "0.0.0.0",
    "extract_flat": False,
}


@dataclass(slots=True)
class Track:
    url: str
    title: str
    duration: int
    thumbnail: str
    webpage_url: str
    requester: Any
    local_path: str | None = None

    @classmethod
    async def from_query(cls, query: str, requester, loop=None) -> list["Track"]:
        loop = loop or asyncio.get_running_loop()
        clean_query = re.sub(r"\(.*?\)", "", query).strip()
        is_url = bool(re.match(r"https?://", query, re.I))
        search_query = query if is_url else f"ytsearch5:{clean_query}"

        def extract():
            return yt_dlp.YoutubeDL(YTDL_OPTIONS).extract_info(search_query, download=False)

        try:
            data = await loop.run_in_executor(None, extract)
        except Exception:
            if is_url:
                raise
            data = await loop.run_in_executor(
                None,
                lambda: yt_dlp.YoutubeDL(YTDL_OPTIONS).extract_info(
                    f"ytsearch5:{clean_query}", download=False
                ),
            )

        if not data:
            raise ValueError("Ничего не найдено")

        entries = data.get("entries") if data.get("entries") is not None else [data]
        entries = [e for e in entries if e]
        if not entries:
            raise ValueError("Ничего не найдено")

        result = []
        for e in entries[:10]:
            webpage_url = e.get("webpage_url") or e.get("original_url") or e.get("url", "")
            stream_url = e.get("url", "")
            if not webpage_url:
                continue
            result.append(
                cls(
                    url=stream_url,
                    title=e.get("title") or "Неизвестно",
                    duration=int(e.get("duration") or 0),
                    thumbnail=e.get("thumbnail") or "",
                    webpage_url=webpage_url,
                    requester=requester,
                )
            )
        return result

    async def refresh_stream_url(self, loop=None) -> str:
        """Получить свежий CDN URL перед запуском трека.

        yt-dlp stream URLs могут протухать, поэтому нельзя надёжно хранить
        исходный URL в очереди на несколько минут.
        """
        loop = loop or asyncio.get_running_loop()

        def extract():
            opts = dict(YTDL_OPTIONS)
            opts.update({"noplaylist": True, "quiet": True, "no_warnings": True})
            info = yt_dlp.YoutubeDL(opts).extract_info(self.webpage_url, download=False)
            if not info:
                raise ValueError("Не удалось получить аудиопоток")
            return info.get("url") or ""

        url = await loop.run_in_executor(None, extract)
        if not url:
            raise ValueError("yt-dlp не вернул URL аудиопотока")
        self.url = url
        return url

    async def download_audio(self, loop=None) -> str:
        """Скачать аудио локально через yt-dlp и вернуть путь к файлу.

        Это запасной и основной способ воспроизведения: прямые CDN-ссылки
        YouTube могут отвечать 403 для FFmpeg даже сразу после извлечения.
        Локальный файл не зависит от срока жизни CDN URL.
        """
        loop = loop or asyncio.get_running_loop()

        def download():
            temp_dir = tempfile.mkdtemp(prefix="kavodedafm_")
            opts = {
                "format": "bestaudio/best",
                "noplaylist": True,
                "quiet": True,
                "no_warnings": True,
                "nocheckcertificate": True,
                "source_address": "0.0.0.0",
                "outtmpl": os.path.join(temp_dir, "%(id)s.%(ext)s"),
                "restrictfilenames": True,
            }
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(self.webpage_url, download=True)
                if not info:
                    raise ValueError("yt-dlp не смог скачать аудио")
                path = ydl.prepare_filename(info)
                if not os.path.isfile(path):
                    # На случай, если yt-dlp изменил расширение после загрузки.
                    files = [
                        os.path.join(temp_dir, name)
                        for name in os.listdir(temp_dir)
                        if os.path.isfile(os.path.join(temp_dir, name))
                    ]
                    if not files:
                        raise FileNotFoundError("Скачанный аудиофайл не найден")
                    path = files[0]
                return path

        self.local_path = await loop.run_in_executor(None, download)
        return self.local_path

    @staticmethod
    def fmt_duration(seconds: int) -> str:
        if not seconds:
            return "∞"
        m, s = divmod(int(seconds), 60)
        h, m = divmod(m, 60)
        return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"

    def __repr__(self):
        return f"<Track title={self.title!r}>"
