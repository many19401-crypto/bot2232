import discord
from discord.ext import commands


class Help(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="help", aliases=["h"])
    async def help_cmd(self, ctx: commands.Context):
        """Список всех команд бота"""
        embed = discord.Embed(
            title="🎵 Музыкальный бот — Команды",
            description="Префикс бота: `!`",
            color=discord.Color.purple(),
        )

        embed.add_field(
            name="▶️ Воспроизведение",
            value=(
                "`!play <ссылка/название>` — включить музыку\n"
                "`!pause` — пауза\n"
                "`!resume` / `!r` — продолжить\n"
                "`!skip` / `!s` — пропустить трек\n"
                "`!stop` — остановить и выйти\n"
                "`!nowplaying` / `!np` — текущий трек"
            ),
            inline=False,
        )

        embed.add_field(
            name="📋 Очередь",
            value=(
                "`!queue` / `!q` — показать очередь\n"
                "`!clear` — очистить очередь\n"
                "`!panel` — открыть панель управления"
            ),
            inline=False,
        )

        embed.add_field(
            name="🔊 Другое",
            value=(
                "`!volume <0-100>` / `!v` — громкость\n"
                "`!join` / `!j` — зайти в канал\n"
                "`!leave` / `!dc` — выйти из канала"
            ),
            inline=False,
        )

        embed.add_field(
            name="🛠 Авто-роль (AutoRole)",
            value=(
                "`!autorole @Роль` — установить авто-роль\n"
                "`!autorole` — посмотреть текущие настройки\n"
                "`!autorolelog #канал` — установить канал для логов\n"
                "`!autoroleoff` — отключить автодобавление роли"
            ),
            inline=False,
        )

        embed.add_field(
            name="🌐 Поддерживаемые источники",
            value="YouTube, SoundCloud, Spotify, Bandcamp, Twitch и многие другие.",
            inline=False,
        )

        embed.set_footer(text="Панель управления появляется автоматически при воспроизведении")
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(Help(bot))