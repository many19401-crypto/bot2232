"""
cogs/voice.py
Подключение и отключение от голосового канала.
"""
import asyncio
import discord
from discord.ext import commands


class Voice(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="join", aliases=["j"])
    async def join(self, ctx: commands.Context):
        """Зайти в твой голосовой канал"""
        if not ctx.author.voice:
            return await ctx.send("❌ Сначала зайди в голосовой канал!")
        channel = ctx.author.voice.channel
        if ctx.voice_client and ctx.voice_client.is_connected():
            await ctx.voice_client.move_to(channel)
            await ctx.send(f"➡️ Перешёл в **{channel.name}**")
            return

        if ctx.voice_client:
            try:
                await ctx.voice_client.disconnect(force=True)
            except Exception:
                pass

        last_error = None
        for attempt in range(1, 4):
            try:
                await channel.connect(timeout=20, reconnect=False, self_deaf=True)
                await ctx.send(f"✅ Зашёл в **{channel.name}**")
                return
            except (discord.ConnectionClosed, asyncio.TimeoutError, discord.ClientException) as exc:
                last_error = exc
                print(f"[voice] !join попытка {attempt}/3: {type(exc).__name__}: {exc}")
                fresh = ctx.guild.voice_client
                if fresh:
                    try:
                        await fresh.disconnect(force=True)
                    except Exception:
                        pass
                if attempt < 3:
                    await asyncio.sleep(attempt * 2)

        await ctx.send(f"❌ Не удалось подключиться: `{last_error}`")

    @commands.command(name="leave", aliases=["dc", "disconnect"])
    async def leave(self, ctx: commands.Context):
        """Выйти из голосового канала"""
        if ctx.voice_client:
            vc = ctx.voice_client
            await vc.disconnect()
            import utils.state as state
            state.clear(ctx.guild.id)
            await ctx.send("👋 Вышел из канала")
        else:
            await ctx.send("❌ Я не в голосовом канале")


async def setup(bot):
    await bot.add_cog(Voice(bot))
