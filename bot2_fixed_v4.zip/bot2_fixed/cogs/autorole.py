import discord
from discord.ext import commands
import json
import os
from datetime import datetime, timezone

class AutoRole(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.file = "data/autorole.json"
        self.data = self.load_data()

    def load_data(self):
        if os.path.exists(self.file):
            with open(self.file, "r", encoding="utf-8") as f:
                data = json.load(f)
            # Миграция старого формата
            for gid, val in list(data.items()):
                if isinstance(val, int):
                    data[gid] = {"role_id": val}
            return data
        return {}

    def save_data(self):
        os.makedirs(os.path.dirname(self.file), exist_ok=True)
        with open(self.file, "w", encoding="utf-8") as f:
            json.dump(self.data, f, indent=4, ensure_ascii=False)

    # ===================== НАСТРОЙКИ =====================

    @commands.command(name="settings", aliases=["config", "настройки"])
    @commands.has_permissions(manage_roles=True)
    async def settings(self, ctx: commands.Context):
        """Показывает все текущие настройки бота"""
        guild_id = str(ctx.guild.id)
        config = self.data.get(guild_id, {})

        role_id = config.get("role_id")
        log_channel_id = config.get("log_channel_id")

        embed = discord.Embed(
            title="⚙️ Настройки бота",
            color=discord.Color.blue()
        )
        embed.add_field(
            name="🛠 Авто-роль",
            value=f"<@&{role_id}>" if role_id else "❌ Не установлена",
            inline=False
        )
        embed.add_field(
            name="📢 Канал логов",
            value=f"<#{log_channel_id}>" if log_channel_id else "❌ Не установлен",
            inline=False
        )
        embed.add_field(
            name="Префикс",
            value="`!`",
            inline=False
        )
        embed.set_footer(text="Используй !help для полного списка команд")
        
        await ctx.send(embed=embed)

    @commands.command(name="autorole", aliases=["ar"])
    @commands.has_permissions(manage_roles=True)
    async def autorole(self, ctx: commands.Context, role: discord.Role = None):
        """Установить / посмотреть авто-роль"""
        guild_id = str(ctx.guild.id)

        if role is None:
            return await self.settings(ctx)  # Если просто !autorole — показываем настройки

        if guild_id not in self.data:
            self.data[guild_id] = {}
        self.data[guild_id]["role_id"] = role.id
        self.save_data()
        await ctx.send(f"✅ Авто-роль установлена: **{role.name}**")

    @commands.command(name="autorolelog", aliases=["arlog"])
    @commands.has_permissions(manage_channels=True)
    async def autorole_log(self, ctx: commands.Context, channel: discord.TextChannel = None):
        """Установить канал для логов"""
        guild_id = str(ctx.guild.id)

        if not channel:
            log_id = self.data.get(guild_id, {}).get("log_channel_id")
            await ctx.send(f"Текущий канал логов: <#{log_id}>" if log_id else "❌ Канал логов не установлен.")
            return

        if guild_id not in self.data:
            self.data[guild_id] = {}
        self.data[guild_id]["log_channel_id"] = channel.id
        self.save_data()
        await ctx.send(f"✅ Канал логов установлен: {channel.mention}")

    @commands.command(name="autoroleoff", aliases=["aroff"])
    @commands.has_permissions(manage_roles=True)
    async def autorole_off(self, ctx: commands.Context):
        """Отключить авто-роль"""
        guild_id = str(ctx.guild.id)
        if guild_id in self.data and "role_id" in self.data[guild_id]:
            del self.data[guild_id]["role_id"]
            if not self.data[guild_id]:
                del self.data[guild_id]
            self.save_data()
            await ctx.send("✅ Автодобавление роли отключено.")
        else:
            await ctx.send("❌ Авто-роль не была настроена.")

    # ===================== ЛОГИ =====================

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        guild_id = str(member.guild.id)
        config = self.data.get(guild_id, {})

        role_id = config.get("role_id")
        log_channel_id = config.get("log_channel_id")

        if not role_id:
            return

        role = member.guild.get_role(role_id)
        if not role:
            return

        try:
            await member.add_roles(role, reason="AutoRole System")

            if log_channel_id:
                log_channel = self.bot.get_channel(log_channel_id)
                if log_channel:
                    embed = discord.Embed(
                        title="🎉 Новый участник получил роль",
                        color=discord.Color.green(),
                        timestamp=datetime.now(timezone.utc)
                    )
                    embed.add_field(name="Участник", value=f"{member.mention} (`{member.id}`)", inline=False)
                    embed.add_field(name="Роль", value=f"{role.mention} (`{role.id}`)", inline=False)
                    embed.set_thumbnail(url=member.display_avatar.url)
                    embed.set_footer(text=f"Сервер: {member.guild.name}")
                    await log_channel.send(embed=embed)

        except discord.Forbidden:
            log_channel = self.bot.get_channel(log_channel_id) if log_channel_id else None
            if log_channel:
                await log_channel.send("❌ Не удалось выдать авто-роль. Проверь права бота и иерархию ролей.")
        except discord.HTTPException as exc:
            print(f"[autorole] Ошибка Discord API: {exc}")


    async def cog_command_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("❌ У тебя недостаточно прав.")
        else:
            await ctx.send(f"❌ Ошибка: `{error}`")


async def setup(bot):
    await bot.add_cog(AutoRole(bot))