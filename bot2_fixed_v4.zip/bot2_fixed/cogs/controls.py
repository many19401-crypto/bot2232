"""
cogs/controls.py
Управление воспроизведением: пауза, продолжить, пропустить, стоп, текущий трек.
"""
import discord
from discord.ext import commands

import utils.state as state
import utils.embeds as embeds
from utils.panel_view import MusicControlView


class Controls(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # ── Пауза ────────────────────────────────────────────────────────────────
    @commands.command(name="pause")
    async def pause(self, ctx: commands.Context):
        """Поставить воспроизведение на паузу"""
        vc = ctx.voice_client
        if vc and vc.is_playing():
            vc.pause()
            await ctx.message.add_reaction("⏸️")
        else:
            await ctx.send("❌ Ничего не играет")

    # ── Продолжить ───────────────────────────────────────────────────────────
    @commands.command(name="resume", aliases=["r"])
    async def resume(self, ctx: commands.Context):
        """Продолжить воспроизведение после паузы"""
        vc = ctx.voice_client
        if vc and vc.is_paused():
            vc.resume()
            await ctx.message.add_reaction("▶️")
        else:
            await ctx.send("❌ Воспроизведение не на паузе")

    # ── Пропустить ───────────────────────────────────────────────────────────
    @commands.command(name="skip", aliases=["s", "next"])
    async def skip(self, ctx: commands.Context):
        """Пропустить текущий трек"""
        vc = ctx.voice_client
        if vc and (vc.is_playing() or vc.is_paused()):
            vc.stop()
            await ctx.message.add_reaction("⏭️")
        else:
            await ctx.send("❌ Ничего не играет")

    # ── Стоп ─────────────────────────────────────────────────────────────────
    @commands.command(name="stop")
    async def stop(self, ctx: commands.Context):
        """Остановить воспроизведение, очистить очередь и выйти из канала"""
        s = state.get(ctx.guild.id)
        s["queue"].clear()
        s["current"] = None
        s["panel_message"] = None
        vc = ctx.voice_client
        if vc:
            vc.stop()
            await vc.disconnect()
        await ctx.message.add_reaction("⏹️")

    # ── Сейчас играет ────────────────────────────────────────────────────────
    @commands.command(name="nowplaying", aliases=["np", "current"])
    async def now_playing(self, ctx: commands.Context):
        """Показать информацию о текущем треке"""
        s = state.get(ctx.guild.id)
        if not s["current"]:
            return await ctx.send("❌ Ничего не играет")
        await ctx.send(embed=embeds.now_playing(s["current"]))

    # ── Панель управления ────────────────────────────────────────────────────
    @commands.command(name="panel")
    async def panel(self, ctx: commands.Context):
        """Открыть интерактивную панель управления музыкой"""
        s = state.get(ctx.guild.id)
        if not s["current"]:
            return await ctx.send("❌ Ничего не играет — нечего показывать")
        view = MusicControlView(ctx.guild.id)
        msg = await ctx.send(embed=embeds.panel(s["current"], len(s["queue"])), view=view)
        s["panel_message"] = msg


async def setup(bot):
    await bot.add_cog(Controls(bot))
